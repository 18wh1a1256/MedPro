import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientLoginComponent } from './patient-login/patient-login.component';
import { PatientRegisterComponent } from './patient-register/patient-register.component';
import { DoctorLoginComponent } from './doctor-login/doctor-login.component';
import { DoctorRegisterComponent } from './doctor-register/doctor-register.component';
import { PharmacyLoginComponent } from './pharmacy-login/pharmacy-login.component';
import { PharmacyRegisterComponent } from './pharmacy-register/pharmacy-register.component';
import { HomeComponent } from './home/home.component';
import { PatientHomeComponent } from './patient-home/patient-home.component';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import {PharmacyHomeComponent } from './pharmacy-home/pharmacy-home.component';
import { LoginHomeComponent } from './login-home/login-home.component';

const routes: Routes = [
{ path: '', redirectTo: '/LoginHome', pathMatch: 'full' },
{ path: 'HomeComponent', component: HomeComponent },
{ path: 'DoctorLoginComponent', component: DoctorLoginComponent  },
{ path: 'PatientLoginComponent', component: PatientLoginComponent },
{ path: 'PharmacyLoginComponent', component: PharmacyLoginComponent },
{ path: 'DoctorRegisterComponent', component: DoctorRegisterComponent },
{ path: 'PatientRegisterComponent', component: PatientRegisterComponent },
{ path: 'PharmacyRegisterComponent', component: PharmacyRegisterComponent },
{path: 'PatientHomeComponent', component: PatientHomeComponent},
{path: 'DoctorHome', component: DoctorHomeComponent},
{path: 'PharmacyHome', component: PharmacyHomeComponent},
{path: 'LoginHome' ,component: LoginHomeComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
