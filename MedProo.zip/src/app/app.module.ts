import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PatientLoginComponent } from './patient-login/patient-login.component';
import { PatientRegisterComponent } from './patient-register/patient-register.component';
import { DoctorLoginComponent } from './doctor-login/doctor-login.component';
import { DoctorRegisterComponent } from './doctor-register/doctor-register.component';
import { PharmacyLoginComponent } from './pharmacy-login/pharmacy-login.component';
import { PharmacyRegisterComponent } from './pharmacy-register/pharmacy-register.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth.guard';
import { PatientHomeComponent } from './patient-home/patient-home.component';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import { PharmacyHomeComponent } from './pharmacy-home/pharmacy-home.component';
import { LoginHomeComponent } from './login-home/login-home.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';

const appRoot: Routes = [
  {path: 'PatientLogin', canActivate: [AuthGuard], component: PatientLoginComponent},
  {path: 'patient-register', canActivate: [AuthGuard], component: PatientRegisterComponent},
  {path: 'DoctorLogin', canActivate: [AuthGuard], component: DoctorLoginComponent},
  {path: 'doctor-register', canActivate: [AuthGuard], component: DoctorRegisterComponent},
  {path: 'PharmacyLogin', canActivate: [AuthGuard], component: PharmacyLoginComponent},
  {path: 'pharmacy-register', canActivate: [AuthGuard], component: PharmacyRegisterComponent},
  {path: 'patient-home', canActivate: [AuthGuard], component: PatientHomeComponent},
  {path: 'doctor-home', canActivate: [AuthGuard], component: DoctorHomeComponent},
  {path : 'pharmacy-home',canActivate: [AuthGuard], component: PharmacyHomeComponent},
  {path: 'login-home', canActivate: [AuthGuard], component: LoginHomeComponent},
];
@NgModule({
  declarations: [
    AppComponent,
    PatientLoginComponent,
    PatientRegisterComponent,
    DoctorLoginComponent,
    DoctorRegisterComponent,
    PharmacyLoginComponent,
    PharmacyRegisterComponent,
    HomeComponent,
    PatientHomeComponent,
    DoctorHomeComponent,
    PharmacyHomeComponent,
    LoginHomeComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,RouterModule.forRoot(appRoot)
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
