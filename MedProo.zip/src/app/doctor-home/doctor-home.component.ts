import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { PatService } from '../pat.service';

@Component({
  selector: 'app-doctor-home',
  templateUrl: './doctor-home.component.html',
  styleUrls: ['./doctor-home.component.css']
})
export class DoctorHomeComponent implements OnInit {
  ApprovedList:Array<any>
  PendingList:Array<any>
  isApproved:boolean;
  isPending:boolean;
  patients: any;
  aptConfirm;
  items: any;


  constructor(private http: HttpClient,private patService: PatService) { }

  ngOnInit(): void {this.patService.getAllApts().subscribe((result: any) => { console.log(result); this.items = result; });
    this.isApproved = false;
    this.isPending = false;
    this.aptConfirm=this.patService.getConfirmApts();
  }
  onApproved(approved:boolean){

    this.isApproved=approved;
    this.isPending=false;
  }
  onPending(pending: boolean){
    this.isPending=pending;
    this.isApproved=false;
  }
  addAptById(item){
    this.patService.addAptById(item);
  }
  getAllApts(){
    this.patService.getAllApts().subscribe((data)=>{
      console.log(data);
      this.aptConfirm = data;
    })
  }

  deletePat(patient: any) {
    this.patService.deletePat(patient).subscribe((result: any) => {
  const i = this.patients.findIndex((element) => {return element.patId === patient.patId;
      });
  this.patients.splice(i , 1);
    });
  }

}
