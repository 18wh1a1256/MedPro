import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PatService } from '../pat.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctor-login',
  templateUrl: './doctor-login.component.html',
  styleUrls: ['./doctor-login.component.css'],
  template: '<div>Doctor Login</div>'
})
export class DoctorLoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  auth2 : any;
  doctor : any;
  DoctorLogged: any;

  constructor( private service: PatService,private router: Router) {
    this.doctor = {docUsername: '', docPassword: ''};
   }

  ngOnInit(): void {
  }

  async loginSubmit(loginForm:any) {
   await this.service.logindoctor(this.doctor.docUsername, this.doctor.docPassword).then((doctor) => {console.log(doctor); this.DoctorLogged = doctor});
    localStorage.setItem('doctor' , JSON.stringify(this.DoctorLogged));
    console.log("Assigned: ", this.DoctorLogged);
    if(this.DoctorLogged != null){
      this.service.setDoctorLoggedIn();
      this.router.navigate(['doctor-home']);
      alert('Logged In Successfully')
    }else{
      alert('Invalid Credentials')
    }
    console.log(loginForm);
  }
}
