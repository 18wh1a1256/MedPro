import { Component, OnInit } from '@angular/core';
import { PatService } from '../pat.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctor-register',
  templateUrl: './doctor-register.component.html',
  styleUrls: ['./doctor-register.component.css']
})
export class DoctorRegisterComponent implements OnInit {
  doctor: any;
  constructor(private service: PatService,private router : Router) { 
  this.doctor={}
 }
  ngOnInit(): void {
  }
  RegisterSubmit(RegisterForm : any): void {
    this.service.regDoctor(RegisterForm).subscribe((result: any)=>{console.log(result);} ) ;
    console.log("registerform" + RegisterForm);
    alert('Registration Successful')
    this.router.navigate(['doctor-home']);
    
  }
}
