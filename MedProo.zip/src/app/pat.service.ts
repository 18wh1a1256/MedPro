import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';

@Injectable({
  providedIn: 'root'
})
export class PatService {
  private isPatientLogged: any;
  catchError:any;
  private isPharmacyLogged: any;
  private isDoctorLogged: any;
  
  docToBeAdded: Subject<any>;
  aptItems=[];
  aptConfirm=[];
  constructor(private httpClient: HttpClient) {
    this.isPatientLogged = false;
    this.isPharmacyLogged = false;
    this.isDoctorLogged = false;
    this.docToBeAdded = new Subject();
  }
 



  setPatientLoggedIn(): void {
    this.isPatientLogged = true;
  }
  setPharmacyLoggedIn(): void {
    this.isPharmacyLogged = true;
  }
  setDoctorLoggedIn(): void {
    this.isDoctorLogged = true;
  }

  //setUserLoggedOut(): void {
   // this.isUserLogged = false;
  //}
  getPatientLogged(): any {
    return this.isPatientLogged;
  }
  getPharmacyLogged(): any {
    return this.isPharmacyLogged;
  }
  getDoctorLogged(): any {
    return this.isDoctorLogged;
  }
  
  regPatient(patient: any) {
    console.log('Inside service',patient);
    return this.httpClient.post('RESTAPI2018/webapi/myresource/regPatient', patient);
  }
  loginpatient(patUsername: any, patPassword:any):any{
  return this.httpClient.get('RESTAPI2018/webapi/myresource/patientLogin/' + patUsername + '/' + patPassword).toPromise();
  //  console.log(" In Service : " + patUsername + " " + patPassword);
  //   return this.httpClient.get('RESTAPI2018/webapi/myresource/patientLogin/' + patUsername + '/' + patPassword);

  }
  logindoctor(docUsername: any, docPassword:any):any{
  return this.httpClient.get('RESTAPI2018/webapi/myresource/doctorLogin/' + docUsername + '/' + docPassword).toPromise();
  }
  loginpharmacy(pharmUsername: any, pharmPassword:any):any{
    return this.httpClient.get('RESTAPI2018/webapi/myresource/pharmacyLogin/' + pharmUsername + '/' + pharmPassword).toPromise();
    }

  regDoctor(doctor: any) {
    return this.httpClient.post('RESTAPI2018/webapi/myresource/regDoctor',  doctor);
  }
  regPharmacy(pharmacy: any) {
    return this.httpClient.post('RESTAPI2018/webapi/myresource/regPharmacy',  pharmacy);
  }
  regAppointment(appointment: any){
    return this.httpClient.post('RESTAPI2018/webapi/myresource/regAppointment', appointment);
  }
  getAllDocs(): any{
    return this.httpClient.get('RESTAPI2018/webapi/myresource/getAllDoctors');
  }
  getAllApts(): any{
    return this.httpClient.get('RESTAPI2018/webapi/myresource/getAllApts');
  }
  addDocById(doctor: any){
    //return this.httpClient.get('RESTAPI2018/webapi/myresource/getDocById/'+ docId);
    //this.docToBeAdded.next(doctor);
    this.aptItems.push(doctor);
  }
  addAptById(item: any){
    this.aptConfirm.push(item);
  }
  delDocById(doctor:any){
    this.aptItems.splice(doctor);
  }
  getAptItems(){
    return this.aptItems;
  }
  getConfirmApts(){
    return this.aptConfirm;
  }
  // getOtp():any{
  //   return this.httpClient.get('RESTAPI2018/webapi/myresource/sendOTP/' + patient.patContact);
  // }
  deletePat(patient: any) {
    return this.httpClient.delete('RESTAPI2018/webapi/myresource/deletePat/' + patient.patId);
  }
  getCoronaCases(): Observable<any>{
    const url= "https://api.covid19api.com/world/total"
    return this.httpClient.get<any>(url)
  }

}


