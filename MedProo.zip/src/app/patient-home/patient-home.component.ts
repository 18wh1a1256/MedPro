import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { PatService } from '../pat.service';

@Component({
  selector: 'app-patient-home',
  templateUrl: './patient-home.component.html',
  styleUrls: ['./patient-home.component.css']
})
export class PatientHomeComponent implements OnInit {

  public token: string = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6InJhbWNoYW5kcmFyZWRkeWRjcDlAZ21haWwuY29tIiwicm9sZSI6IlVzZXIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9zaWQiOiI3NDQ5IiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy92ZXJzaW9uIjoiMjAwIiwiaHR0cDovL2V4YW1wbGUub3JnL2NsYWltcy9saW1pdCI6Ijk5OTk5OTk5OSIsImh0dHA6Ly9leGFtcGxlLm9yZy9jbGFpbXMvbWVtYmVyc2hpcCI6IlByZW1pdW0iLCJodHRwOi8vZXhhbXBsZS5vcmcvY2xhaW1zL2xhbmd1YWdlIjoiZW4tZ2IiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL2V4cGlyYXRpb24iOiIyMDk5LTEyLTMxIiwiaHR0cDovL2V4YW1wbGUub3JnL2NsYWltcy9tZW1iZXJzaGlwc3RhcnQiOiIyMDIwLTA3LTIwIiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWF1dGhzZXJ2aWNlLnByaWFpZC5jaCIsImF1ZCI6Imh0dHBzOi8vaGVhbHRoc2VydmljZS5wcmlhaWQuY2giLCJleHAiOjE2MDA1MzE1MTgsIm5iZiI6MTYwMDUyNDMxOH0.nKlqaTNJvXyfq7DSzGGP2JTkeg0aXuwklXY1qW11mxg&format=json&language=en-gb'
  public baseUrl: string = 'https://sandbox-healthservice.priaid.ch/issues?token='
  public selectedsymptom: string = '';
  symptomList: Array<any>;

  public token1: string ='/info?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6InJhbWNoYW5kcmFyZWRkeWRjcDlAZ21haWwuY29tIiwicm9sZSI6IlVzZXIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9zaWQiOiI3NDQ5IiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy92ZXJzaW9uIjoiMjAwIiwiaHR0cDovL2V4YW1wbGUub3JnL2NsYWltcy9saW1pdCI6Ijk5OTk5OTk5OSIsImh0dHA6Ly9leGFtcGxlLm9yZy9jbGFpbXMvbWVtYmVyc2hpcCI6IlByZW1pdW0iLCJodHRwOi8vZXhhbXBsZS5vcmcvY2xhaW1zL2xhbmd1YWdlIjoiZW4tZ2IiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL2V4cGlyYXRpb24iOiIyMDk5LTEyLTMxIiwiaHR0cDovL2V4YW1wbGUub3JnL2NsYWltcy9tZW1iZXJzaGlwc3RhcnQiOiIyMDIwLTA3LTIwIiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWF1dGhzZXJ2aWNlLnByaWFpZC5jaCIsImF1ZCI6Imh0dHBzOi8vaGVhbHRoc2VydmljZS5wcmlhaWQuY2giLCJleHAiOjE2MDA1MzE1NDksIm5iZiI6MTYwMDUyNDM0OX0.DeHeKSLLopIRbGY2lkcX5CgQLGpNSz7eTjkrCpJZPcM&format=json&language=en-gb'
  public Url1: string = 'https://sandbox-healthservice.priaid.ch/issues/'
  issue: any;
  issueName: Array<any>;

  public token3: string =']&gender=female&year_of_birth=1982&token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6InJhbWNoYW5kcmFyZWRkeWRjcDlAZ21haWwuY29tIiwicm9sZSI6IlVzZXIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9zaWQiOiI3NDQ5IiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy92ZXJzaW9uIjoiMjAwIiwiaHR0cDovL2V4YW1wbGUub3JnL2NsYWltcy9saW1pdCI6Ijk5OTk5OTk5OSIsImh0dHA6Ly9leGFtcGxlLm9yZy9jbGFpbXMvbWVtYmVyc2hpcCI6IlByZW1pdW0iLCJodHRwOi8vZXhhbXBsZS5vcmcvY2xhaW1zL2xhbmd1YWdlIjoiZW4tZ2IiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL2V4cGlyYXRpb24iOiIyMDk5LTEyLTMxIiwiaHR0cDovL2V4YW1wbGUub3JnL2NsYWltcy9tZW1iZXJzaGlwc3RhcnQiOiIyMDIwLTA3LTIwIiwiaXNzIjoiaHR0cHM6Ly9zYW5kYm94LWF1dGhzZXJ2aWNlLnByaWFpZC5jaCIsImF1ZCI6Imh0dHBzOi8vaGVhbHRoc2VydmljZS5wcmlhaWQuY2giLCJleHAiOjE2MDA1MzE1NzUsIm5iZiI6MTYwMDUyNDM3NX0.1Tfz2QEfmgJ42g_ehCskTqo8aftIRGxv-WvUIVA-w98&format=json&language=en-gb';
  public Url3: string = 'https://sandbox-healthservice.priaid.ch/diagnosis/specialisations?symptoms=['
  specialist: string = '';
  specialistList : Array<any>;

  // public token2: string = 'world/total';
  // public Url2: string = 'https://api.covid19api.com/'
  // summary: string = '';
  // summaryList : Array<any>;



  isExcercises: boolean;
  isVideos: boolean;
  isTipsAndFacts: boolean;
  isMakeAppointments: boolean;
  isMyAppointments: boolean;
  isPharmContact: boolean;
  isEmergency: boolean;
  isSymptoms: boolean;
  isCovid: boolean;
  TotalConfirmed: any;
  TotalDeaths: any;
  TotalRecovered: any;
  DescriptionShort: any;
  PossibleSymptoms: any;
  MedicalCondition: any;
  TreatmentDescription: any;
  Name: Array<any>;
  docFirstName: any;
  docSpecialisation: any;
  docContact: any;
  docList: Array<any>;
  doctors: any;
  aptList;
  appointment: any;


  constructor(private http: HttpClient, private patService: PatService) { }

  ngOnInit(): void {this.patService.getAllDocs().subscribe((result: any) => { console.log(result); this.doctors = result; });
  let temp = `${this.Url3}${this.selectedsymptom}${this.token3}`;
    console.log(temp)
    this.http.get<any>(temp).subscribe(data =>{
      
      this.Name = data;
      console.log(data)      
    })
    this.aptList=this.patService.getAptItems();
}

  onSymptoms(symptoms:boolean){
    this.isSymptoms=symptoms;
    let temp = `${this.baseUrl}${this.token}`;
    console.log(temp)
    this.http.get<any>(temp).subscribe(data => {
      console.log(data)
      this.symptomList = data
      
    })
    this.isCovid=false;
    this.isExcercises = false;
    this.isVideos = false;
    this.isTipsAndFacts = false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isPharmContact = false;
    this.isEmergency = false;
 }
  onCovid(covid:boolean){
    this.isCovid=covid;
    this.isExcercises=false;
    this.isSymptoms = false;
    this.isVideos = false;
    this.isTipsAndFacts = false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isPharmContact = false;
    this.isEmergency = false;
  }
  onExcercises(excercises:boolean){
    this.isExcercises=excercises;
    this.isSymptoms = false;
    this.isCovid=false;
    this.isVideos = false;
    this.isTipsAndFacts = false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isPharmContact = false;
    this.isEmergency = false;
  }
  onVideos(videos:boolean){
    this.isVideos=videos;
    this.isCovid=false;
    this.isSymptoms = false;
    this.isExcercises=false;
    this.isTipsAndFacts = false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isPharmContact = false;
    this.isEmergency = false;
  }
  onTipsAndFacts(tipsAndFacts:boolean){
    this.isTipsAndFacts=tipsAndFacts;
    this.isSymptoms = false;
    this.isCovid=false;
    this.isExcercises=false;
    this.isVideos=false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isPharmContact = false;
    this.isEmergency = false;
  }
  onMyAppointments(myAppointments:boolean){
    this.isMyAppointments=myAppointments;
    this.isSymptoms = false;
    this.isCovid=false;
    this.isExcercises=false;
    this.isVideos=false;
    this.isMakeAppointments = false;
    this.isTipsAndFacts = false;
    this.isPharmContact = false;
    this.isEmergency = false;
  }
  onMakeAppointments(makeAppointments:boolean){
    this.isMakeAppointments=makeAppointments;
    this.isSymptoms = false;
    this.isCovid=false;
    this.isExcercises=false;
    this.isVideos=false;
    this.isMyAppointments = false;
    this.isTipsAndFacts = false;
    this.isPharmContact = false;
    this.isEmergency = false;
  }

  onPharmContact(pharmcontact:boolean){
    this.isPharmContact=pharmcontact;
    this.isSymptoms = false;
    this.isCovid=false;
    this.isExcercises=false;
    this.isVideos=false;
    this.isTipsAndFacts = false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isEmergency = false;
    this.isTipsAndFacts = false;

  }
  onEmergency(emergency:boolean){
    this.isEmergency=emergency;
    this.isCovid=false;
    this.isSymptoms = false;
    this.isExcercises=false;
    this.isVideos=false;
    this.isTipsAndFacts=false;
    this.isMyAppointments = false;
    this.isMakeAppointments = false;
    this.isPharmContact = false;
  }
  getIssues() {
    let temp = `${this.Url1}${this.selectedsymptom}${this.token1}`
    console.log(temp)
    this.http.get<any>(temp).subscribe(data => {
      console.log(data)
      this.DescriptionShort = data.DescriptionShort;
      this.PossibleSymptoms = data.PossibleSymptoms;
      this.MedicalCondition = data.MedicalCondition;
      this.TreatmentDescription = data.TreatmentDescription;      
    })
  }
  getSpecialist(){
    let temp = `${this.Url3}${this.selectedsymptom}${this.token3}`;
    console.log(temp)
    this.http.get<any>(temp).subscribe(data =>{
      
      this.Name = data;
      console.log(data)      
    })
  }
  // getSummary(){
    
  //   let temp = `${this.Url2}${this.token2}`;
  //   console.log(temp)
  //   this.http.get<any>(temp).subscribe(data =>{
  //     this.summaryList = data;
  //     console.log(data)
  //   })  
  //}
  addDocById(doctor){
    this.patService.addDocById(doctor);
    
  }
  delDocById(doctor){
    this.patService.delDocById(doctor);
    alert('deleted');
  }
  openForm() {
    document.getElementById("myForm").style.display = "block";
  }

  closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
  RegisterSubmit(RegisterForm : any): void{
    this.patService.regAppointment(RegisterForm).subscribe((result: any)=>{console.log("Shiv result"+result);});
    console.log("aptForm" + RegisterForm);
    alert('Apt added');
  }
  
  getCoronaCases(){
    this.patService.getCoronaCases().subscribe((data)=>{
      console.log(data)
      this.TotalConfirmed= data.TotalConfirmed
      this.TotalDeaths= data.TotalDeaths
      this.TotalRecovered= data.TotalRecovered
    })
  }
  getAllDocs(){
    this.patService.getAllDocs().subscribe((data)=>{
      console.log(data)
      this.docList = data;
    })
  }
}
