import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { PatService } from '../pat.service';

@Component({
  selector: 'app-patient-login',
  templateUrl: './patient-login.component.html',
  styleUrls: ['./patient-login.component.css'],
  template: '<div>Patient Login</div>',
})

export class PatientLoginComponent implements OnInit {
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  auth2 : any;
  patient : any;
  PatientLogged: any;

  constructor( private service: PatService,private router: Router) {
    this.patient = {patUsername: '', patPassword: ''};
   }

  ngOnInit(): void {
  }
  async loginSubmit(loginForm:any) {
   await this.service.loginpatient(this.patient.patUsername, this.patient.patPassword).then((patient) => {console.log(patient); this.PatientLogged = patient});
    localStorage.setItem('patient' , JSON.stringify(this.PatientLogged));
    console.log("Assigned: ", this.PatientLogged);
    if(this.PatientLogged != null){
      this.service.setPatientLoggedIn();
      this.router.navigate(['patient-home']);
      alert('Logged In Successfully')
    }else{
      alert('Invalid Credentials')
    }
    console.log(loginForm);
  }

}


