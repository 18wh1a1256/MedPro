import { Component, OnInit } from '@angular/core';
import { PatService } from '../pat.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-register',
  templateUrl: './patient-register.component.html',
  styleUrls: ['./patient-register.component.css']
})
export class PatientRegisterComponent implements OnInit {
patient: any;
  constructor(private service : PatService,private router : Router ) {
    //this.patient = { patId:'1', patFirstName: 'abc', patLastName: 'xyz' ,address: 'abcdefgh', password: '123456', patContact: '79652266', patAge: '56'};
  this.patient={}; 
  }

  ngOnInit(): void {
  }
  RegisterSubmit(RegisterForm : any): void {
    this.service.regPatient(RegisterForm).subscribe((result: any)=>{console.log("Shiv result"+result);}) ;
    console.log("registerform" + RegisterForm);
    alert('Registration Successful')
    this.router.navigate(['patient-home']);
  }
}
