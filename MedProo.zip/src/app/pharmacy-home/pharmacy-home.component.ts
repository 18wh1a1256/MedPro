import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pharmacy-home',
  templateUrl: './pharmacy-home.component.html',
  styleUrls: ['./pharmacy-home.component.css']
})
export class PharmacyHomeComponent implements OnInit {
  ApprovedList:Array<any>
  PendingList:Array<any>
  isApproved:boolean;
  isPending:boolean; 

  constructor() { }

  ngOnInit(): void {
    this.isApproved = false;
    this.isPending = false;
    this.ApprovedList=  [
      {
        PatientName: 'Aishu',
        Address:'H.No :100,Bachupally',
        contact: '9381756671',
        condition: 'Kidney Stones',
      },
      {
        PatientName: 'Rakshitha',
        Address:'H.No :102,Lingampally',
        contact: '9381756671',
        condition: 'Headache',
      },
      {
        PatientName: 'Shivani',
        Address: 'H.no 108,BHEL',
        contact: '9381756672',
        condition: 'Cold',
      }
    ]
    this.PendingList=[
      {
        PatientName: 'Sarayu',
        Address:'H.no 208,Vikarabad',
        contact: '9381756671',
        condition: 'Kidney Stones',
      },
      {
        PatientName: 'Uma',
        Address:'H.no 405,Nizamabad',
        contact: '9381756673',
        condition: 'Headache',
      },
      {
        PatientName: 'Deepthi',
        Address:'H.no 408,Kukatpally',
        contact: '9381756672',
        condition: 'Cold',
      }
    ]
  
  }
  onApproved(approved:boolean){

    this.isApproved=approved;
    this.isPending=false;
  }
  onPending(pending: boolean){
    this.isPending=pending;
    this.isApproved=false;
  }

}

