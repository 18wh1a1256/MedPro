import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PatService } from '../pat.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pharmacy-login',
  templateUrl: './pharmacy-login.component.html',
  styleUrls: ['./pharmacy-login.component.css'],
  template: '<div>Pharmacy Login</div>'
})
export class PharmacyLoginComponent implements OnInit {
  @ViewChild('loginRef', { static: true }) loginElement: ElementRef;
  auth2: any;
  pharmacy: any;
  PharmacyLogged: any;

  constructor(private service: PatService, private router: Router) {
    this.pharmacy = { pharmUsername: '', pharmPassword: '' };
  }

  ngOnInit(): void {
  }


  async loginSubmit(loginForm: any) {
    await this.service.loginpharmacy(this.pharmacy.pharmUsername, this.pharmacy.pharmPassword).then((pharmacy) => { console.log(pharmacy); this.PharmacyLogged = pharmacy });
    localStorage.setItem('pharmacy', JSON.stringify(this.PharmacyLogged));
    console.log("Assigned: ", this.PharmacyLogged);
    if(this.PharmacyLogged != null) {
      this.service.setPharmacyLoggedIn();
      this.router.navigate(['pharmacy-home']);
      alert('Logged In Successfully')
    } else {
      alert('Invalid Credentials')
    }
    console.log(loginForm);
  }
}