import { Component, OnInit } from '@angular/core';
import { PatService } from '../pat.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pharmacy-register',
  templateUrl: './pharmacy-register.component.html',
  styleUrls: ['./pharmacy-register.component.css']
})
export class PharmacyRegisterComponent implements OnInit {
  pharmacy: any;
  constructor(private service: PatService, private router: Router) {

    this.pharmacy = {};
  }
  ngOnInit(): void {
  }
  RegisterSubmit(RegisterForm: any): void {
    this.service.regPharmacy(RegisterForm).subscribe((result: any) => { console.log("Shiv result" + result); });
    console.log("registerform" + RegisterForm);
    alert('Registration Successful')
    this.router.navigate(['pharmacy-home']);
  }
}
